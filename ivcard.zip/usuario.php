<?php

echo '
    {
        "nome": "José Bernardo Wernik Conselheiro",
        "imagem" : "https://ibsweb.com.br/wp-content/uploads/2021/10/bernardo-1024x964.jpg",
        "icones":[
            {"url": "#","icone": "email","title":"E-mail"},
            {"url": "#","icone": "phone","title":"Chamada"},
            {"url": "#","icone": "instagram","title":"Instagram"},
            {"url": "#","icone": "site","title":"Site"},
            {"url": "#","icone": "location","title":"Endereço"}
        ]
    }
';
exit();