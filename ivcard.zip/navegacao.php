<?php

echo '[
    {
        "type": "icones",
        "icones": [
            {"url": "#","icone": "twitter","title":"Twitter"},
            {"url": "#","icone": "facebook","title":"Facebook"},
            {"url": "#","icone": "youtube","title":"You tube"},
            {"url": "#","icone": "whatsapp","title":"WhatsApp"},
            {"url": "#","icone": "tiktok","title":"TikTok"},
            {"url": "#","icone": "email","title":"E-mail"},
            {"url": "#","icone": "phone","title":"Chamada"},
            {"url": "#","icone": "instagram","title":"Instagram"},
            {"url": "#","icone": "site","title":"Site"},
            {"url": "#","icone": "location","title":"Endereço"}
        ]
    },
    {
        "type": "modelos",
        "modelos": [
            {
                "id": 1,
                "url": "modelos/celular-2-2.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-3-3.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-5-1.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular_4-2.webp"
            },
            {
                "id": 1,
                "url": "modelos/celular-2-2.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-3-3.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-5-1.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular_4-2.webp"
            },
            {
                "id": 1,
                "url": "modelos/celular-2-2.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-3-3.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-5-1.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular_4-2.webp"
            },
            {
                "id": 1,
                "url": "modelos/celular-2-2.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-3-3.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-5-1.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular_4-2.webp"
            },
            {
                "id": 1,
                "url": "modelos/celular-2-2.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-3-3.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-5-1.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular_4-2.webp"
            },
            {
                "id": 1,
                "url": "modelos/celular-2-2.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-3-3.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-5-1.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular_4-2.webp"
            },
            {
                "id": 1,
                "url": "modelos/celular-2-2.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-3-3.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular-5-1.webp"
            },
            {
                "id": 2,
                "url": "modelos/celular_4-2.webp"
            }
        ]
    }
]';
exit();